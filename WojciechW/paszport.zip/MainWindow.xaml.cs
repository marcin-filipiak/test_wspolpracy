﻿using System.IO;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace paszportWPF
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }

		private void AktualizujZdjecia(object sender, RoutedEventArgs e)
		{
            string numer = ((TextBox) sender).Text;
            try
            {
				zdjecie1.Source = new BitmapImage(new Uri("pack://application:,,,/Images/" + numer + "-zdjecie.jpg"));
				zdjecie2.Source = new BitmapImage(new Uri("pack://application:,,,/Images/" + numer + "-odcisk.jpg"));
			} catch(IOException)
            {
                zdjecie1.Source = null;
                zdjecie2.Source = null;
			}

		}

		private void WyswietlKomunikat(object sender, RoutedEventArgs e)
		{
            if(string.IsNullOrEmpty(imie.Text) || string.IsNullOrEmpty(nazwisko.Text)) 
            {
                MessageBox.Show("Wprowadź dane");
                return;
            }
            string kolorOczu = "";
            if (kolorOczuNiebieski.IsChecked == true)
            {
                kolorOczu = "niebieski";
            }
            else if (kolorOczuZielony.IsChecked == true)
            {
                kolorOczu = "zielony";
            }
            else if (kolorOczuPiwny.IsChecked == true)
            {
                kolorOczu = "piwny";
            }
            MessageBox.Show($"{imie.Text} {nazwisko.Text} kolor oczu {kolorOczu}");
		}
	}
}