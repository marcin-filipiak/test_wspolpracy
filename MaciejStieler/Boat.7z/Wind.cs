﻿using System;

namespace BoatNavigator
{
    public class Wind
    {
        private static readonly string[] Directions = { "Zachód", "Południe", "Północ", "Wschód" };
        private int _directionIndex;
        public string Direction { get; private set; }
        public int Speed { get; private set; }

        public Wind()
        {
            _directionIndex = 0;
            Direction = Directions[_directionIndex];
            Speed = 10;
        }

        public void ChangeWind()
        {
            _directionIndex = (_directionIndex + 1) % Directions.Length; 
            Direction = Directions[_directionIndex];

            Speed += new Random().Next(-2, 3); 
            if (Speed < 0) Speed = 0; 
        }

        public double GetWindEffect(double boatAngle)
        {
            double windAngle = 0;
            switch (Direction)
            {
                case "Zachód": windAngle = 0; break;
                case "Południe": windAngle = 180; break;
                case "Północ": windAngle = 90; break;
                case "Wschód": windAngle = 270; break;
            }

            double angleDifference = Math.Abs(boatAngle - windAngle);
            if (angleDifference > 180) angleDifference = 360 - angleDifference;

            double windEffect = 0;
            if (angleDifference < 90)
            {
                windEffect = (1 - angleDifference / 90) * 3; 
            }
            else
            {
                windEffect = 0;
            }

            return windEffect;
        }
    }
}
