﻿using Microsoft.Maui.Graphics;

namespace BoatNavigator
{
    public class Boat
    {
        public double X { get; set; } = 100; // Startowa pozycja
        public double Y { get; set; } = 100;
        public double Angle { get; private set; } = 0; // Kąt obrotu w stopniach

        private const double BaseSpeed = 5; // Podstawowa prędkość łódki
        private Wind _wind; // Obiekt wiatr

        public Boat(Wind wind)
        {
            _wind = wind;
        }

        public void MoveForward()
        {
            // Pobieranie wpływu wiatru na prędkość łódki
            double windEffect = _wind.GetWindEffect(Angle);

            // Zmieniona prędkość łódki w zależności od wiatru
            double currentSpeed = BaseSpeed + windEffect;

            double radians = Angle * (Math.PI / 180); // Konwersja kąta na radiany
            X += Math.Cos(radians) * currentSpeed;
            Y += Math.Sin(radians) * currentSpeed;
        }

        public void RotateLeft() => Angle -= 15;
        public void RotateRight() => Angle += 15;
    }
}
