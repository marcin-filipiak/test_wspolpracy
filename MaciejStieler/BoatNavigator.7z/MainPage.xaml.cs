﻿using System;
using Microsoft.Maui.Controls;
using Microsoft.Maui.Dispatching;

namespace BoatNavigator
{
    public partial class MainPage : ContentPage
    {
        private readonly Boat _boat;
        private readonly Wind _wind;

        public MainPage()
        {
            InitializeComponent();

            _wind = new Wind(); // Inicjalizacja wiatru
            _boat = new Boat(_wind); // Przekazanie wiatru do łódki

            // Timer do przesuwania łódki
            Device.StartTimer(TimeSpan.FromMilliseconds(50), () =>
            {
                MoveBoat();
                return true; // `true` oznacza, że timer będzie działał w nieskończoność
            });

            UpdateBoat();
        }

        private void OnLeftClicked(object sender, EventArgs e)
        {
            _boat.RotateLeft();
            UpdateBoat();
        }

        private void OnRightClicked(object sender, EventArgs e)
        {
            _boat.RotateRight();
            UpdateBoat();
        }

        private void MoveBoat()
        {
            _boat.MoveForward();
            UpdateBoat();
        }

        private void UpdateBoat()
        {
            BoatImage.TranslationX = _boat.X;
            BoatImage.TranslationY = _boat.Y;
            BoatImage.Rotation = _boat.Angle;

            // Aktualizacja informacji o wietrze
            WindInfoLabel.Text = $"Wiatr: {_wind.Direction} {_wind.Speed} km/h";
        }

        // Zmiana wiatru po kliknięciu przycisku
        private void OnChangeWindClicked(object sender, EventArgs e)
        {
            _wind.ChangeWind(); // Zmiana kierunku i prędkości wiatru
        }
    }
}
