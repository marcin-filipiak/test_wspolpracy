﻿namespace AplikacjaEgzamTest
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            label2 = new Label();
            label3 = new Label();
            label1 = new Label();
            groupBox1 = new GroupBox();
            piwneRadio = new RadioButton();
            zieloneRadio = new RadioButton();
            niebieskieRadio = new RadioButton();
            NumerTextBox = new TextBox();
            ImieTextBox = new TextBox();
            NazwiskoTextBox = new TextBox();
            zdjeciePictureBox = new PictureBox();
            odciskPictureBox = new PictureBox();
            button1 = new Button();
            groupBox1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)zdjeciePictureBox).BeginInit();
            ((System.ComponentModel.ISupportInitialize)odciskPictureBox).BeginInit();
            SuspendLayout();
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Location = new Point(68, 107);
            label2.Name = "label2";
            label2.Size = new Size(30, 15);
            label2.TabIndex = 1;
            label2.Text = "Imię";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Location = new Point(68, 150);
            label3.Name = "label3";
            label3.Size = new Size(57, 15);
            label3.TabIndex = 2;
            label3.Text = "Nazwisko";
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new Point(68, 67);
            label1.Name = "label1";
            label1.Size = new Size(44, 15);
            label1.TabIndex = 3;
            label1.Text = "Numer";
            // 
            // groupBox1
            // 
            groupBox1.Controls.Add(piwneRadio);
            groupBox1.Controls.Add(zieloneRadio);
            groupBox1.Controls.Add(niebieskieRadio);
            groupBox1.Location = new Point(68, 216);
            groupBox1.Name = "groupBox1";
            groupBox1.Size = new Size(381, 118);
            groupBox1.TabIndex = 4;
            groupBox1.TabStop = false;
            groupBox1.Text = "Kolor oczu";
            // 
            // piwneRadio
            // 
            piwneRadio.AutoSize = true;
            piwneRadio.Location = new Point(26, 72);
            piwneRadio.Name = "piwneRadio";
            piwneRadio.Size = new Size(57, 19);
            piwneRadio.TabIndex = 2;
            piwneRadio.Text = "piwne";
            piwneRadio.UseVisualStyleBackColor = true;
            // 
            // zieloneRadio
            // 
            zieloneRadio.AutoSize = true;
            zieloneRadio.Location = new Point(26, 47);
            zieloneRadio.Name = "zieloneRadio";
            zieloneRadio.Size = new Size(62, 19);
            zieloneRadio.TabIndex = 1;
            zieloneRadio.Text = "zielone";
            zieloneRadio.UseVisualStyleBackColor = true;
            // 
            // niebieskieRadio
            // 
            niebieskieRadio.AutoSize = true;
            niebieskieRadio.Checked = true;
            niebieskieRadio.Location = new Point(26, 22);
            niebieskieRadio.Name = "niebieskieRadio";
            niebieskieRadio.Size = new Size(77, 19);
            niebieskieRadio.TabIndex = 0;
            niebieskieRadio.TabStop = true;
            niebieskieRadio.Text = "niebieskie";
            niebieskieRadio.UseVisualStyleBackColor = true;
            // 
            // NumerTextBox
            // 
            NumerTextBox.BackColor = Color.Azure;
            NumerTextBox.Location = new Point(175, 64);
            NumerTextBox.Name = "NumerTextBox";
            NumerTextBox.Size = new Size(231, 23);
            NumerTextBox.TabIndex = 5;
            NumerTextBox.Leave += NumerLeave;
            // 
            // ImieTextBox
            // 
            ImieTextBox.BackColor = Color.Azure;
            ImieTextBox.Location = new Point(175, 104);
            ImieTextBox.Name = "ImieTextBox";
            ImieTextBox.Size = new Size(231, 23);
            ImieTextBox.TabIndex = 6;
            // 
            // NazwiskoTextBox
            // 
            NazwiskoTextBox.BackColor = Color.Azure;
            NazwiskoTextBox.Location = new Point(175, 147);
            NazwiskoTextBox.Name = "NazwiskoTextBox";
            NazwiskoTextBox.Size = new Size(231, 23);
            NazwiskoTextBox.TabIndex = 7;
            // 
            // zdjeciePictureBox
            // 
            zdjeciePictureBox.BackColor = Color.CadetBlue;
            zdjeciePictureBox.Location = new Point(525, 64);
            zdjeciePictureBox.Name = "zdjeciePictureBox";
            zdjeciePictureBox.Size = new Size(128, 180);
            zdjeciePictureBox.SizeMode = PictureBoxSizeMode.StretchImage;
            zdjeciePictureBox.TabIndex = 8;
            zdjeciePictureBox.TabStop = false;
            // 
            // odciskPictureBox
            // 
            odciskPictureBox.Location = new Point(726, 64);
            odciskPictureBox.Name = "odciskPictureBox";
            odciskPictureBox.Size = new Size(125, 180);
            odciskPictureBox.SizeMode = PictureBoxSizeMode.StretchImage;
            odciskPictureBox.TabIndex = 9;
            odciskPictureBox.TabStop = false;
            // 
            // button1
            // 
            button1.BackColor = Color.Azure;
            button1.Location = new Point(561, 288);
            button1.Name = "button1";
            button1.Size = new Size(267, 60);
            button1.TabIndex = 10;
            button1.Text = "OK";
            button1.UseVisualStyleBackColor = false;
            button1.Click += ButtonOkClicked;
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.CadetBlue;
            ClientSize = new Size(933, 407);
            Controls.Add(button1);
            Controls.Add(odciskPictureBox);
            Controls.Add(zdjeciePictureBox);
            Controls.Add(NazwiskoTextBox);
            Controls.Add(ImieTextBox);
            Controls.Add(NumerTextBox);
            Controls.Add(groupBox1);
            Controls.Add(label1);
            Controls.Add(label3);
            Controls.Add(label2);
            Name = "Form1";
            Text = "Wprowadzenie danych do paszportu. Wykonał: Wiktor Gieruszczak";
            groupBox1.ResumeLayout(false);
            groupBox1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)zdjeciePictureBox).EndInit();
            ((System.ComponentModel.ISupportInitialize)odciskPictureBox).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion
        private Label label2;
        private Label label3;
        private Label label1;
        private GroupBox groupBox1;
        private RadioButton piwneRadio;
        private RadioButton zieloneRadio;
        private RadioButton niebieskieRadio;
        private TextBox NumerTextBox;
        private TextBox ImieTextBox;
        private TextBox NazwiskoTextBox;
        private PictureBox zdjeciePictureBox;
        private PictureBox odciskPictureBox;
        private Button button1;
    }
}
