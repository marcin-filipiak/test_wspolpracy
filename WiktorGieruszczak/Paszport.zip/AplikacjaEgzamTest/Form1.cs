namespace AplikacjaEgzamTest
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }


        private void NumerLeave(object sender, EventArgs e)
        {
            if (File.Exists("C:\\Users\\uczen\\source\\repos\\AplikacjaEgzamTest\\AplikacjaEgzamTest\\Images\\" + NumerTextBox.Text+"-zdjecie.jpg") && File.Exists("C:\\Users\\uczen\\source\\repos\\AplikacjaEgzamTest\\AplikacjaEgzamTest\\Images\\" + NumerTextBox.Text+"-odcisk.jpg"))
            {
                zdjeciePictureBox.Image = Image.FromFile("C:\\Users\\uczen\\source\\repos\\AplikacjaEgzamTest\\AplikacjaEgzamTest\\Images\\" + NumerTextBox.Text + "-zdjecie.jpg");
                odciskPictureBox.Image = Image.FromFile("C:\\Users\\uczen\\source\\repos\\AplikacjaEgzamTest\\AplikacjaEgzamTest\\Images\\" + NumerTextBox.Text + "-odcisk.jpg");
            }
            else
            {
                odciskPictureBox.Image = null;
                zdjeciePictureBox.Image = null;
            }
        }

        private void ButtonOkClicked(object sender, EventArgs e)
        {
            if (NumerTextBox.Text.Length < 1)
                return;
            
            if(NazwiskoTextBox.Text.Length < 1 || ImieTextBox.Text.Length < 1)
            {
                MessageBox.Show("Wprowad� dane");
                return;
            }

            MessageBox.Show($"{ImieTextBox.Text} {NazwiskoTextBox.Text} kolor oczu: {(niebieskieRadio.Checked ? "niebieskie" : (zieloneRadio.Checked ? "zielone" : "piwne"))}");
        }
    }
}
