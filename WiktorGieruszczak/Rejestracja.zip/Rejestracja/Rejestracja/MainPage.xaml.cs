﻿namespace Rejestracja
{
    public partial class MainPage : ContentPage
    {
        public MainPage()
        {
            InitializeComponent();
        }

        private void SprawdzZatwierdzone(object sender, EventArgs e)
        {
            string entryEmail = EntryEmail.Text;
            if (!entryEmail.Contains('@'))
            {
                ObszarKomunikatow.Text = "Nieprawidłowy adres e-mail";
                return;
            }

            int firstPasswordLength = EntryPassword.Text.Length;
            int secondPasswordLength = EntrySecondPassword.Text.Length;
            if (firstPasswordLength != secondPasswordLength)
            {
                ObszarKomunikatow.Text = "Hasła się różnią";
                return;
            }

            ObszarKomunikatow.Text = $"Witaj {entryEmail}";
        }
    }

}
