﻿namespace BoatSimulation
{
    public class Boat
    {
        private int x = 170;
        private int y = 170;

        public int Angle { get; set; }
        private int direction;

        public int Direction
        {
            get => direction;
            set => direction = value % 360;
        }

        public double Speed { get; set; }

        public int X
        {
            get => x;
            set
            {
                if (value <= 340 && value >= 0)
                {
                    x = value;
                }
            }
        }

        public int Y
        {
            get => y;
            set
            {
                if (value <= 340 && value >= 0)
                {
                    y = value;
                }
            }
        }

        public void Update(double windAngle)
        {
            double myAngle = (Angle - windAngle + 360) % 360;
            if (myAngle > 180)
                myAngle -= 360;

            Speed = WhatSpeed(myAngle);

            X += (int)(Speed * Math.Cos(Direction * Math.PI / 180));
            Y += (int)(Speed * Math.Sin(Direction * Math.PI / 180));
        }

        private double WhatSpeed(double thatAngle)
        {
            if (Math.Abs(thatAngle) <= 10)
                return 0;

            else if (Math.Abs(thatAngle) > 5 && Math.Abs(thatAngle) <= 45)
                return 3 * 0.2;

            else if (Math.Abs(thatAngle) > 45 && Math.Abs(thatAngle) <= 90)
                return 3 * 0.5;

            else if (Math.Abs(thatAngle) > 90 && Math.Abs(thatAngle) <= 135)
                return 3 * 0.8;

            else if (Math.Abs(thatAngle) > 135 && Math.Abs(thatAngle) <= 180)
                return 3;

            return 0;
        }
    }
}
