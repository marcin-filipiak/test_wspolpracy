﻿namespace BoatSimulation
{
    public partial class MainPage : ContentPage
    {
        private Wind MapWind;
        private Boat GameBoat;

        public MainPage()
        {
            InitializeComponent();
            MapWind = new Wind();
            GameBoat = new Boat();
        }

        protected override async void OnAppearing()
        {
            await StartGame();
        }

        private async Task StartGame()
        {
            MapWind.StartWind();

            StartSomeShit();

            while (true)
            {
                GameBoat.Update(MapWind.Angle);

                int katBajdena = (MapWind.Angle - GameBoat.Direction) < 0 ? (MapWind.Angle - GameBoat.Direction)+360 : (MapWind.Angle - GameBoat.Direction);
                katBajdena %= 360;

                WhichWindGupieNazwy.Text = $"Wiatr: {MapWind.JakaNazwaWiatru(katBajdena)}";

                Absolut.SetLayoutBounds(BoatContainer, new Rect(GameBoat.X, GameBoat.Y, 60, 60));

                await Task.Delay(60);
            }
        }

        private void StartSomeShit()
        {
            int tenDoPokazania = MapWind.Angle - 90 < 0 ? MapWind.Angle + 270 : MapWind.Angle - 90;

            WindDirection.Text = $"Kąt wiatru: {tenDoPokazania}";
            compass.Rotation = tenDoPokazania;
        }

        private void TurnLeft(object sender, EventArgs e)
        {
            ChangeBoatRotation(-2);
        }

        private void TurnRight(object sender, EventArgs e)
        {
            ChangeBoatRotation(2);
        }

        private void ChangeBoatRotation(int number)
        {
            GameBoat.Angle += number;
            GameBoat.Direction += number;
            Boat.Rotation = GameBoat.Angle;
        }

        private void ControlsInput(object sender, TextChangedEventArgs e)
        {
            string thatText = ((Entry)sender).Text;

            if (thatText is null)
                return;

            if (thatText.Contains('a'))
                ChangeBoatRotation(-2);
            
            else if (thatText.Contains('d'))
                ChangeBoatRotation(2);
            
            ControlsInputEntry.Text = "";
        }
    }

}
