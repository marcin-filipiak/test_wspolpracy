﻿namespace BoatSimulation
{
    public class Wind
    {
        public int Angle { get; set; }

        private Random random = new Random();

        public void StartWind()
        {
            Angle = random.Next(0, 360);
        }

        public string JakaNazwaWiatru(int kat) =>
            kat switch
            {
                < 225 and > 135 => "Martwy kąt",
                < 269 and > 91 => "Bajdewind",
                < 275 and > 89 => "Polwiatr",
                > 30 and < 330 => "Baksztag",
                _ => "Fordewind"
            };

    }
}
