using System;
using Microsoft.Maui;
using Microsoft.Maui.Hosting;

namespace INF._04_01_21._06_SG
{
    internal class Program : MauiApplication
    {
        protected override MauiApp CreateMauiApp() => MauiProgram.CreateMauiApp();

        static void Main(string[] args)
        {
            var app = new Program();
            app.Run(args);
        }
    }
}
