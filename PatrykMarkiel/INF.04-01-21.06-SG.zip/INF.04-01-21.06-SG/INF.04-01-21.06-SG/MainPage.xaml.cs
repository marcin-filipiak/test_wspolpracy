﻿namespace INF._04_01_21._06_SG
{
    public partial class MainPage : ContentPage
    {

        public MainPage()
        {
            InitializeComponent();
        }
        private void Button_Clicked(object sender, EventArgs e)
        {
            string userEmail = email.Text;
            string userPassword = password.Text;
            string userPassword2 = password2.Text;

            if (userEmail.Contains("@"))
            {
                if (userPassword == userPassword2)
                {
                    respond.Text = $"witaj {userEmail}";
                }
                else
                {
                    respond.Text = $"hasła się nie zgadzają";
                }
            }
            else
            {
                respond.Text = "wpisz email";
            }
        }
    }
}
