﻿namespace boat_game;

public partial class MainPage : ContentPage
{
    private double _refreshRate = 30;
    private double _rotation = 0;
    private double _windDirection = 0;
    private double _positionX = 0;
    private double _positionY = 0;
    private double _deadAngle = 10;
    private double _speed = 2;
    private double _rotationSpeed = 2;
    private double _currentSpeed = 0;
    private double _speedChangeRate = 0.05;

    private IDispatcherTimer _timer;
    private IDispatcherTimer _turnTimer;

    public MainPage()
    {
        InitializeComponent();

        GetRandomWindDirection();

        _timer = Dispatcher.CreateTimer();
        _timer.Interval = TimeSpan.FromMilliseconds(_refreshRate);
        _timer.Tick += OnTimerTick;
        _timer.Start();

        _turnTimer = Dispatcher.CreateTimer();
        _turnTimer.Interval = TimeSpan.FromMilliseconds(_refreshRate);
    }

    private void OnTurnLeftButtonPressed(object sender, EventArgs e)
    {
        _turnTimer.Tick += OnTurnLeft;
        _turnTimer.Start();
    }

    private void OnTurnLeftButtonReleased(object sender, EventArgs e)
    {
        _turnTimer.Tick -= OnTurnLeft;
        _turnTimer.Stop();
    }

    private void OnTurnRightButtonPressed(object sender, EventArgs e)
    {
        _turnTimer.Tick += OnTurnRight;
        _turnTimer.Start();
    }

    private void OnTurnRightButtonReleased(object sender, EventArgs e)
    {
        _turnTimer.Tick -= OnTurnRight;
        _turnTimer.Stop();
    }

    private double LerpRotation(double start, double end, double t)
    {
        double delta = (end - start + 360) % 360;
        if (delta > 180) delta -= 360;
        return start + delta * t;
    }

    private void OnTurnLeft(object sender, EventArgs e)
    {
        _rotation -= _rotationSpeed;
        if (_rotation < 0) _rotation += 360;
        boatImage.Rotation = LerpRotation(boatImage.Rotation, _rotation, 0.1);
        UpdateRotation();
    }

    private void OnTurnRight(object sender, EventArgs e)
    {
        _rotation += _rotationSpeed;
        if (_rotation >= 360) _rotation -= 360;
        boatImage.Rotation = LerpRotation(boatImage.Rotation, _rotation, 0.1);
        UpdateRotation();
    }

    private void OnTimerTick(object sender, EventArgs e)
    {
        var radians = _rotation * Math.PI / 180;

        var targetSpeed = GetSpeed();
        _currentSpeed = LerpSpeed(_currentSpeed, targetSpeed, _speedChangeRate);  

        _positionX += _currentSpeed * Math.Sin(radians);
        _positionY += _currentSpeed * -Math.Cos(radians);

        ClampPosition();

        boatImage.TranslationX = _positionX;
        boatImage.TranslationY = _positionY;

        sailImage.TranslationX = _positionX;
        sailImage.TranslationY = _positionY;

        sailImage.Rotation = GetSailRotation();
        compassImage.Rotation = _windDirection;
    }

    private double LerpSpeed(double currentSpeed, double targetSpeed, double t)
    {
        return currentSpeed + (targetSpeed - currentSpeed) * t;
    }

    private void UpdateRotation()
    {
        rotationLbl.Text = $"{_rotation}°";
        sailImage.Rotation = GetSailRotation();
    }

    private double GetSpeed()
    {
        var relativeAngle = Math.Abs((_rotation - _windDirection + 360) % 360);
        if (relativeAngle > 180) relativeAngle = Math.Abs(relativeAngle - 360);

        double[] speedMultipliers = {
            0.05, 0.6, 0.8, 0.9, 1.0, 0.95, 0.9, 0.85, 1.0, 0.95, 1.0, 0.8, 0.6, 0.3
        };

        if (relativeAngle < 30 || relativeAngle > 330)
            return _speed * speedMultipliers[0];
        else if (relativeAngle < 45)
            return _speed * speedMultipliers[1];
        else if (relativeAngle < 60)
            return _speed * speedMultipliers[2];
        else if (relativeAngle < 90)
            return _speed * speedMultipliers[3];
        else if (relativeAngle == 90)
            return _speed * speedMultipliers[4];
        else if (relativeAngle <= 135)
            return _speed * speedMultipliers[5];
        else if (relativeAngle <= 150)
            return _speed * speedMultipliers[6];
        else if (relativeAngle <= 180)
            return _speed * speedMultipliers[7];
        else if (relativeAngle == 180)
            return _speed * speedMultipliers[8];
        else if (relativeAngle <= 225)
            return _speed * speedMultipliers[9];
        else if (relativeAngle <= 270)
            return _speed * speedMultipliers[10];
        else if (relativeAngle <= 300)
            return _speed * speedMultipliers[11];
        else if (relativeAngle <= 315)
            return _speed * speedMultipliers[12];
        else
            return _speed * speedMultipliers[13];
    }

    private double GetSailRotation()
    {
        var relativeAngle = (_windDirection - _rotation + 360) % 360;
        if (relativeAngle > 180) relativeAngle -= 360;
        return relativeAngle / 2;
    }

    private void ClampPosition()
    {
        var maxX = (Width / 2) - boatImage.Width / 2;
        var minX = -(Width / 2) + boatImage.Width / 2;
        var maxY = -(Height / 2) + boatImage.Height / 2;
        var minY = (Height / 2) - boatImage.Height / 2;

        _positionX = Math.Min(Math.Max(_positionX, minX), maxX);
        _positionY = Math.Min(Math.Max(_positionY, maxY), minY);
    }

    private void GetRandomWindDirection()
    {
        _windDirection = new Random().Next(0, 360);
        windDirectionLbl.Text = $"Wind: {_windDirection}°";
    }
}
