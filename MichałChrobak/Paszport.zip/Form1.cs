using Microsoft.VisualBasic.ApplicationServices;
using System.Drawing;

namespace Paszport;

public partial class Form1 : Form
{
	public Form1()
	{
		InitializeComponent();

		pictureBox1.Image = Image.FromFile(@"C:\Users\uczen\source\repos\Paszport\Images\000-zdjecie.jpg");
		pictureBox2.Image = Image.FromFile(@"C:\Users\uczen\source\repos\Paszport\Images\000-odcisk.jpg");
	}

	private void TextBoxLeave(object sender, EventArgs e)
	{
		string filename = $@"C:\Users\uczen\source\repos\Paszport\Images\{number.Text}-zdjecie.jpg";
		string filename1 = $@"C:\Users\uczen\source\repos\Paszport\Images\{number.Text}-odcisk.jpg";
		pictureBox1.Image = File.Exists(filename) ? Image.FromFile(filename) : null;
		pictureBox2.Image = File.Exists(filename1) ? Image.FromFile(filename1) : null;
	}

	private void ButtonClick(object sender, EventArgs e)
	{
		if (textBox2.Text == string.Empty || textBox3.Text == string.Empty)
		{
			MessageBox.Show("Wprowad� dane");
			return;
		}
		string color = string.Empty;
		if (radioButton1.Checked)
			color = radioButton1.Text;
		if (radioButton2.Checked)
			color = radioButton2.Text;
		if (radioButton3.Checked)
			color = radioButton3.Text;
		MessageBox.Show($"{textBox2.Text} {textBox3.Text} kolor oczu {color}");
	}
}
