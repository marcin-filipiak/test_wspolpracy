﻿namespace Sailor;

public partial class MainPage : ContentPage
{
	private readonly Boat boat = new();
	private int windDirection = 0;

	public MainPage()
	{
		InitializeComponent();
		Prepare();
		compass.Rotation = windDirection;
		Tick();

	}

	private async void Tick()
	{
		Random rand = new();
		while (true)
		{
			await Task.Delay(40);
			boat.Speed(windDirection);
			UpdateBoat();
		}
	}

	private void UpdateBoat()
	{
		boat.Move();
		Lake.SetLayoutBounds(boatObject, new Rect(boat.Position.X, boat.Position.Y, 64, 64));
	}

	private void Prepare()
	{
		Random rand = new();
		windDirection = rand.Next(13) * 30;
		windDirection -= 180;
	}

	private void LeftButtonClick(object sender, EventArgs e)
	{
		boat.Rotation += 30;

		boatObject.Rotation = boat.Rotation;
	}

	private void RightButtonClick(object sender, EventArgs e)
	{
		boat.Rotation -= 30;

		boatObject.Rotation = boat.Rotation;
	}
}
