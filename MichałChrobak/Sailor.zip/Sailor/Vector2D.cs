﻿namespace Sailor;

internal class Vector2D
{
    public float X { get; set; }
    public float Y { get; set; }
    public Vector2D(float x, float y)
    {
        X = x;
        Y = y;
    }
    public Vector2D()
    {
        X = 0;
        Y = 0;
    }

    public static implicit operator Vector2D((float x, float y) val) => new(val.x, val.y);
    public void Deconstruct(out float x, out float y)
    {
        x = X;
        y = Y;
    }

    public static Vector2D operator +(Vector2D a, Vector2D b) => new(a.X + b.X, a.Y + b.Y);
    public static Vector2D operator -(Vector2D a, Vector2D b) => new(a.X - b.X, a.Y - b.Y);
    public static Vector2D operator *(Vector2D a, Vector2D b) => new(a.X * b.X, a.Y * b.Y);
    public static Vector2D operator /(Vector2D a, Vector2D b) => new(a.X / b.X, a.Y / b.Y);
    public static Vector2D operator *(Vector2D a, float b) => new(a.X * b, a.Y * b);
}
