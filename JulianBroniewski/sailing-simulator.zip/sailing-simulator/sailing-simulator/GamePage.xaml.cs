namespace sailing_simulator;

public partial class GamePage : ContentPage
{
    int windDirection;
    System.Timers.Timer _timer;

    double currentSpeedX = 0, currentSpeedY = 0;
    double acceleration = 0.05;
    double friction = 0.98;

    public GamePage()
    {
        InitializeComponent();

        // kierunek wiatru
        Random r = new Random();
        windDirection = r.Next(0, 360);

        windLabel.Text = "The direction of wind: " + windDirection.ToString() + "�";
        directionIndicator.Rotation = windDirection;

        boat.TranslationX = (waterSurface.Width - boat.Width) / 2;
        boat.TranslationY = (waterSurface.Height - boat.Height) / 2;

        _timer = new System.Timers.Timer(16);
        _timer.Elapsed += (sender, e) =>
        {
            MainThread.BeginInvokeOnMainThread(() =>
            {
                MoveBoat();
            });
        };

        _timer.Start();
    }

    // sterowanie ��dk�
    private void toPortsideButton_Clicked(object sender, EventArgs e)
    {
        RotateBoat(-2);
    }

    private void toStarboardButton_Clicked(object sender, EventArgs e)
    {
        RotateBoat(2);
    }

    private void RotateBoat(int angle)
    {
        boat.Rotation += angle;

        if (boat.Rotation < 0)
        {
            boat.Rotation += 360;
        }

        if (boat.Rotation > 360)
        {
            boat.Rotation -= 360;
        }

        boatLabel.Text = "The direction of boat: " + boat.Rotation + "�";

        TrimSails();
    }

    private void MoveBoat()
    {
        float angleDifference = CalculateAngleDifference();
        float speed = Math.Max(0, (180 - angleDifference) / 160);

        double rotationInRadians = Math.PI * boat.Rotation / 180;
        double targetSpeedX = speed * Math.Sin(rotationInRadians);
        double targetSpeedY = -speed * Math.Cos(rotationInRadians);

        currentSpeedX += (targetSpeedX - currentSpeedX) * acceleration;
        currentSpeedY += (targetSpeedY - currentSpeedY) * acceleration;

        currentSpeedX *= friction;
        currentSpeedY *= friction;

        double waterSurfaceWidth = waterSurface.Width;
        double waterSurfaceHeight = waterSurface.Height;

        double newX = boat.TranslationX + currentSpeedX;
        double newY = boat.TranslationY + currentSpeedY;

        double boatWidth = boat.Width;
        double boatHeight = boat.Height;

        if (newX < 0) newX = 0;
        if (newX > waterSurfaceWidth - boatWidth) newX = waterSurfaceWidth - boatWidth;

        if (newY < 0) newY = 0;
        if (newY > waterSurfaceHeight - boatHeight) newY = waterSurfaceHeight - boatHeight;

        boat.TranslationX = newX;
        boat.TranslationY = newY;
    }

    private float CalculateAngleDifference()
    {
        float angleDifference = Math.Abs((float)(windDirection - boat.Rotation));

        if (angleDifference > 180)
            angleDifference = 360 - angleDifference;

        return angleDifference;
    }

    private void TrimSails(/* r�nica kierunk�w!!! */)
    {
        //
    }
}
