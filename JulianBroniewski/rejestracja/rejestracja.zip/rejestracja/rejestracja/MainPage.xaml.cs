﻿namespace rejestracja
{
    public partial class MainPage : ContentPage
    {
        public MainPage()
        {
            InitializeComponent();

            messageLabel.Text = "Autor: 00000000000";
        }

        private void Button_Clicked(object sender, EventArgs e)
        {
            if (emailEntry.Text != null && passwordEntry.Text != null && passwordRepeatEntry.Text != null)
            {
                string message = "";

                if (!emailEntry.Text.Contains("@"))
                {
                    message = "Nieprawidłowy adres e-mail";
                }
                else if (passwordEntry.Text != passwordRepeatEntry.Text)
                {
                    message = "Hasła się różnią";
                }
                else
                {
                    message = "Witaj " + emailEntry.Text;
                }

                messageLabel.Text = message;
            }
        }
    }
}
