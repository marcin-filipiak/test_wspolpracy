namespace sailing_simulator;

public partial class GamePage : ContentPage
{
    int windDirection;
    System.Timers.Timer _timer;

    double currentSpeedX = 0, currentSpeedY = 0;
    double acceleration = 0.05;
    double friction = 0.98;

    string previousBoatImage = string.Empty;
    double previousBoatRotation = -1;

    bool isRotatingLeft = false;
    bool isRotatingRight = false;

    int trimSailsCounter = 0;

    public GamePage()
    {
        InitializeComponent();

        // kierunek wiatru
        Random r = new Random();
        windDirection = r.Next(0, 360);

        windLabel.Text = "The direction of wind: " + windDirection.ToString() + "�";
        directionIndicator.Rotation = windDirection;

        float angleDifference = CalculateAngleDifference();
        TrimSails(angleDifference);

        _timer = new System.Timers.Timer(16);
        _timer.Elapsed += (sender, e) =>
        {
            MainThread.BeginInvokeOnMainThread(() =>
            {
                MoveBoat();
            });
        };

        _timer.Start();
    }

    // sterowanie ��dk�
    private void toPortsideButton_Pressed(object sender, EventArgs e)
    {
        isRotatingLeft = true;
    }

    private void toPortsideButton_Released(object sender, EventArgs e)
    {
        isRotatingLeft = false;
    }

    private void toStarboardButton_Pressed(object sender, EventArgs e)
    {
        isRotatingRight = true;
    }

    private void toStarboardButton_Released(object sender, EventArgs e)
    {
        isRotatingRight = false;
    }

    private void RotateBoat(int angle)
    {
        const double rotationSpeed = 1;
        boat.Rotation += angle * rotationSpeed;

        if (boat.Rotation < 0)
        {
            boat.Rotation += 360;
        }

        if (boat.Rotation > 360)
        {
            boat.Rotation -= 360;
        }

        boatLabel.Text = "The direction of boat: " + (int)boat.Rotation + "�";

        float angleDifference = CalculateAngleDifference();
        TrimSails(angleDifference);
    }

    private DateTime lastRotationTime = DateTime.MinValue;
    private TimeSpan rotationDelay = TimeSpan.FromMilliseconds(100);

    private void MoveBoat()
    {
        float angleDifference = CalculateAngleDifference();
        float speed = Math.Max(0, (180 - angleDifference) / 160);

        double rotationInRadians = Math.PI * boat.Rotation / 180;
        double targetSpeedX = speed * Math.Sin(rotationInRadians);
        double targetSpeedY = -speed * Math.Cos(rotationInRadians);

        currentSpeedX += (targetSpeedX - currentSpeedX) * acceleration;
        currentSpeedY += (targetSpeedY - currentSpeedY) * acceleration;

        currentSpeedX *= friction;
        currentSpeedY *= friction;

        double waterSurfaceWidth = waterSurface.Width;
        double waterSurfaceHeight = waterSurface.Height;

        double newX = boat.TranslationX + currentSpeedX;
        double newY = boat.TranslationY + currentSpeedY;

        double boatWidth = boat.Width;
        double boatHeight = boat.Height;

        boat.TranslationX = newX;
        boat.TranslationY = newY;

        DateTime currentTime = DateTime.Now;

        if (isRotatingLeft && currentTime - lastRotationTime > rotationDelay)
        {
            RotateBoat(-2); // Rotacja w lewo
            lastRotationTime = currentTime; // Aktualizacja czasu
        }

        if (isRotatingRight && currentTime - lastRotationTime > rotationDelay)
        {
            RotateBoat(2); // Rotacja w prawo
            lastRotationTime = currentTime; // Aktualizacja czasu
        }

        trimSailsCounter++;
        if (trimSailsCounter >= 5)
        {
            TrimSails(angleDifference);
            trimSailsCounter = 0;
        }
    }


    private float CalculateAngleDifference()
    {
        float angleDifference = Math.Abs((float)(windDirection - boat.Rotation));

        if (angleDifference > 180)
            angleDifference = 360 - angleDifference;

        return angleDifference;
    }

    // manipulacja �aglami
    private void TrimSails(float angleDifference)
    {
        float NormalizeAngle(float angle) => (angle % 360 + 360) % 360;

        float normalizedWindDirection = NormalizeAngle(windDirection);
        float normalizedBoatRotation = NormalizeAngle((float)boat.Rotation);

        string newBoatImage = "";

        if (angleDifference > 160)
        {
            newBoatImage = "boat_bow_to_wind.png";
            positionLabel.Text = "Position: Head to wind";
        }
        else if (angleDifference > 20)
        {
            float diff = normalizedBoatRotation - normalizedWindDirection;

            if (Math.Abs(diff) > 180) diff -= Math.Sign(diff) * 360;

            newBoatImage = diff > 0 ? "boat_star_to_wind.png" : "boat_port_to_wind.png";
            positionLabel.Text = "Position: Reaching";
        }
        else
        {
            newBoatImage = "boat_stern_to_wind.png";
            positionLabel.Text = "Position: Running";
        }

        if (newBoatImage != previousBoatImage || Math.Abs(boat.Rotation - previousBoatRotation) > 10)
        {
            boat.Source = newBoatImage;
            previousBoatImage = newBoatImage;
            previousBoatRotation = boat.Rotation;
        }
    }
}
