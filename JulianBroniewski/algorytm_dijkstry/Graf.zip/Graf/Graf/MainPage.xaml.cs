﻿namespace Graf
{
    public partial class MainPage : ContentPage
    {
        int ab;
        int bc;
        int ca;

        const int INF = (int)1e9;                                           // "Nieskończoność" - duża liczba
        const int N = 3;                                                    // Liczba wierzchołków

        int[,] graph;                                                       // Macierz sąsiedztwa - wagi krawędzi

        public MainPage()
        {
            InitializeComponent();
        }

        private void CalculateButton_Clicked(object sender, EventArgs e)
        {
            ab = Int32.Parse(abEntry.Text);
            bc = Int32.Parse(bcEntry.Text);
            ca = Int32.Parse(caEntry.Text);

            graph = new int[N, N]
            {
                {0, ab, ca},
                {ab, 0, bc},
                {ca, bc, 0}
            };

            graphLabel.Text = "          (A)\n          /   \\\n   " + ab + "   /       \\  " + bc + "\n      /           \\\n   (B) ------- (C)\n           " + ca;

            Dijkstra(0, 1);
        }

        void Dijkstra(int start, int end)
        {
            int[] dist = new int[N];
            bool[] visited = new bool[N];                                   // Czy wierzchołek był odwiedzony?
            int[] parent = new int[N];                                      // Tablica przechowująca poprzedników wierzchołków
            PriorityQueue<int, int> pq = new PriorityQueue<int, int>();     // Min-heap

            // Inicjalizacja tablic
            for (int i = 0; i < N; i++)
            {
                dist[i] = INF;
                visited[i] = false;
                parent[i] = -1;                                             // Brak rodzica dla wierzchołka początkowego
            }

            dist[start] = 0;                                                // Startowy wierzchołek ma odległość 0
            pq.Enqueue(start, 0);                                           // Dodajemy wierzchołek startowy do kolejki priorytetowej

            while (pq.Count > 0)
            {
                // Znajdujemy wierzchołek o najmniejszej odległości
                int minVertex = pq.Dequeue();
                if (visited[minVertex])
                {
                    continue;
                }

                visited[minVertex] = true;                                  // Oznaczamy jako odwiedzony

                // Aktualizujemy odległości sąsiadów
                for (int j = 0; j < N; j++)
                {
                    if (graph[minVertex, j] != 0 && !visited[j])            // Jeżeli istnieje krawędź
                    {
                        int newDist = dist[minVertex] + graph[minVertex, j];
                        if (newDist < dist[j])
                        {
                            dist[j] = newDist;
                            parent[j] = minVertex;                          // Ustawiamy rodzica dla wierzchołka j
                            pq.Enqueue(j, dist[j]);                         // Dodajemy wierzchołek do kolejki z nową odległością
                        }
                    }
                }
            }

            // Rekonstrukcja ścieżki
            List<int> path = new List<int>();
            int current = end;
            while (current != -1)
            {
                path.Add(current);
                current = parent[current];
            }

            path.Reverse();                                                 // Odwracamy, bo ścieżka została zbudowana od końca

            // Wyświetlanie wyników
            resultLabel.Text = "Najkrótsza droga z A do " + (char)('A' + end) + ":\n";
            if (dist[end] == INF)
            {
                resultLabel.Text += "Brak drogi\n";
            }
            else
            {
                foreach (var vertex in path)
                {
                    resultLabel.Text += (char)('A' + vertex) + " ";
                }
                resultLabel.Text += ", koszt: " + dist[end] + "\n";
            }
        }

    }
}
