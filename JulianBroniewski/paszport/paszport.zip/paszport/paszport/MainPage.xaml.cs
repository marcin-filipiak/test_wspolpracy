﻿namespace paszport
{
    public partial class MainPage : ContentPage
    {
        public MainPage()
        {
            InitializeComponent();
        }

        protected override void OnAppearing()
        {
            base.OnAppearing();
            Window.Title = "Wprowadzenie danych do paszportu. Wykonał: 0000000000";
        }

        private void numer_Unfocused(object sender, FocusEventArgs e)
        {
            zdjecie.Source = "C:\\Users\\uczen\\Desktop\\paszporty\\" + numer.Text + "-zdjecie.jpg";
            odcisk.Source = "C:\\Users\\uczen\\Desktop\\paszporty\\" + numer.Text + "-odcisk.jpg";
        }

        private void OK_Clicked(object sender, EventArgs e)
        {
            if (!string.IsNullOrEmpty(numer.Text) && !string.IsNullOrEmpty(imie.Text) && !string.IsNullOrEmpty(nazwisko.Text))
            {
                string kolorOczu = "";
                if (niebieskie.IsChecked)
                    kolorOczu = "niebieskie";
                else if (zielone.IsChecked)
                    kolorOczu = "zielone";
                else if (brazowe.IsChecked)
                    kolorOczu = "brązowe";

                string message = $"{imie.Text} {nazwisko.Text}, kolor oczu {kolorOczu}";
                DisplayAlert("", message, "OK");
            }
            else
            {
                DisplayAlert("", "Wprowadź dane", "OK");
            }
        }
    }
}
