﻿using Timer = System.Timers.Timer;

namespace BoatSimulator
{
    public partial class MainPage : ContentPage
    {
        private double _boatAngle = 0;
        private double _windAngle;
        private double _windSpeed;  // Prędkość w węzłach (knots)
        private double _boatSpeed;  // Prędkość łódki w węzłach
        private readonly Random _random = new();
        private readonly Timer _windTimer;
        private double _boatX = 0.5;  // Pozycja względna (0 - 1)
        private double _boatY = 0.5;  // Pozycja względna (0 - 1)
        private const double AreaWidth = 600;
        private const double AreaHeight = 700;
        private const double BoatWidth = 40;  // Szerokość łódki
        private const double BoatHeight = 40;  // Wysokość łódki
        private const double KnotToKmH = 1.852;  // Konwersja z węzłów na km/h

        public MainPage()
        {
            InitializeComponent();

            _windTimer = new Timer(30000);  // Co 30 sekund zmiana warunków wiatru
            _windTimer.Elapsed += (s, e) => UpdateWindConditions();
            _windTimer.Start();

            UpdateWindConditions();
            Device.StartTimer(TimeSpan.FromMilliseconds(100), MoveBoat);  // Timer co 100 ms
        }

        private void UpdateWindConditions()
        {
            _windAngle = _random.Next(0, 360);  // Kierunek wiatru w stopniach
            _windSpeed = _random.Next(5, 10);   // Prędkość wiatru w węzłach (knots)
            UpdateBoatSpeed();
        }

        private void UpdateBoatSpeed()
        {
            double angleDiff = Math.Abs(_boatAngle - _windAngle) % 360;
            _boatSpeed = _windSpeed * (1 - Math.Cos(angleDiff * Math.PI / 180));

            const double speedFactor = 0.5;
            _boatSpeed *= speedFactor;
        }

        private bool MoveBoat()
        {
            UpdateBoatSpeed();
            double deltaX = _boatSpeed * Math.Cos(_boatAngle * Math.PI / 180);
            double deltaY = _boatSpeed * Math.Sin(_boatAngle * Math.PI / 180);

            // Zaktualizowana pozycja łódki w układzie względnym (od 0 do 1)
            _boatX = Math.Clamp(_boatX + deltaX / AreaWidth, 0 + BoatWidth / AreaWidth, 1 - BoatWidth / AreaWidth);
            _boatY = Math.Clamp(_boatY + deltaY / AreaHeight, 0 + BoatHeight / AreaHeight, 1 - BoatHeight / AreaHeight);

            // Obliczenie nowych współrzędnych łódki w AbsoluteLayout
            AbsoluteLayout.SetLayoutBounds(Boat, new Rect(_boatX - BoatWidth / (2 * AreaWidth), _boatY - BoatHeight / (2 * AreaHeight), BoatWidth / AreaWidth, BoatHeight / AreaHeight));
            Boat.Rotation = _boatAngle;

            // Wyświetlanie wszystkich informacji w InfoLabel
            InfoLabel.Text = $"Wind: {_windSpeed * KnotToKmH:F2} km/h, {GetWindDirection(_windAngle)} ({_windAngle}°)\n" +
                             $"Boat: {_boatSpeed * KnotToKmH:F2} km/h, {_boatAngle}°";

            return true;
        }

        // Metoda przekształcająca kąt wiatru na kierunek geograficzny
        private string GetWindDirection(double angle)
        {
            if (angle >= 0 && angle < 22.5)
                return "N";
            if (angle >= 22.5 && angle < 67.5)
                return "NE";
            if (angle >= 67.5 && angle < 112.5)
                return "E";
            if (angle >= 112.5 && angle < 157.5)
                return "SE";
            if (angle >= 157.5 && angle < 202.5)
                return "S";
            if (angle >= 202.5 && angle < 247.5)
                return "SW";
            if (angle >= 247.5 && angle < 292.5)
                return "W";
            if (angle >= 292.5 && angle < 337.5)
                return "NW";
            return "N"; // W przypadku błędu lub kąta 360°
        }

        private void LeftButton_Clicked(object sender, EventArgs e)
        {
            _boatAngle -= 10;
            // Utrzymanie kąta w zakresie 0-360
            if (_boatAngle < 0) _boatAngle += 360;
            Boat.Rotation = _boatAngle;
        }

        private void RightButton_Clicked(object sender, EventArgs e)
        {
            _boatAngle += 10;
            // Utrzymanie kąta w zakresie 0-360
            if (_boatAngle >= 360) _boatAngle -= 360;
            Boat.Rotation = _boatAngle;
        }
    }

}
