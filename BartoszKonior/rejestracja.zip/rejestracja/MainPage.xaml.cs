﻿using Microsoft.Maui.Controls;
using System;

namespace rejestracja
{
    public partial class MainPage : ContentPage
    {
        public MainPage()
        {
            InitializeComponent();
        }

        private void OnSubmit(object sender, EventArgs e)
        {
            string email = EmailEntry.Text;
            string password = PasswordEntry.Text;
            string confirmPassword = ConfirmPasswordEntry.Text;

            if (string.IsNullOrWhiteSpace(email) || string.IsNullOrWhiteSpace(password) || string.IsNullOrWhiteSpace(confirmPassword)) return;
            
            if (!email.Contains("@"))
            {
                MessageLabel.Text = "Nieprawidłowy adres e-mail";
                return;
            }

            if (password != confirmPassword)
            {
                MessageLabel.Text = "Hasła się różnią";
                return;
            }

            MessageLabel.Text = $"Witaj {email}";
        }
    }

}
