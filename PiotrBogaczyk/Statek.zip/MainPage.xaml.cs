﻿using System;
using System.Threading.Tasks;
using Microsoft.Maui.Controls;

namespace Statek
{
    public partial class MainPage : ContentPage
    {
        double positionX = 0;
        double positionY = 0;
        double currentRotation;

        private Random _random = new Random();
        private readonly string _windDirection;

        private double _windAngle = 0;
        private double _currentSpeedFactor = 0;

        public MainPage()
        {
            InitializeComponent();

            _windAngle = _random.Next(0, 361);

            _windDirection = GetWindDirectionName(_windAngle);

            WindDirectionLabel.Text = $"Kierunek Wiatru: {_windDirection}, Kąt: {_windAngle}°";
            SpeedLabel.Text = $"Prędkość: {_currentSpeedFactor * 100:F0}%";
            WindName.Text = $"Typ wiatru: {GetWindType((_windAngle - currentRotation + 360) % 360)}";
            Arrow.Rotation = _windAngle - 90;

            Loaded += (sender, args) =>
            {
                double frameCenterX = BoundaryFrame.Width / 2;
                double frameCenterY = BoundaryFrame.Height / 2;
                double squareCenterX = Square.Width / 2;
                double squareCenterY = Square.Height / 2;

                positionX = frameCenterX - squareCenterX;
                positionY = frameCenterY - squareCenterY;

                Square.TranslationX = positionX;
                Square.TranslationY = positionY;
            };

            AutomaticMovement();
        }
        private string GetWindType(double angle)
        {
            if (angle < 22.5 || angle >= 337.5) return "Martwy kąt";

            if (angle >= 22.5 && angle < 45) return "Bajdewind"; 

            if (angle >= 45 && angle < 67.5) return "Szeroki Bajdewind"; 

            if (angle >= 67.5 && angle < 90) return "Półwiatr"; 

            if (angle >= 90 && angle < 112.5) return "Szeroki Baksztag (część)"; 

            if (angle >= 112.5 && angle < 135) return "Baksztag (część)"; 

            if (angle >= 135 && angle < 157.5) return "Baksztag"; 

            if (angle >= 157.5 && angle < 202.5) return "Fordewind"; 

            if (angle >= 202.5 && angle < 225) return "Szeroki Fordewind"; 

            if (angle >= 225 && angle < 247.5) return "Półwiatr (część)"; 

            if (angle >= 247.5 && angle < 270) return "Szeroki Bajdewind (część)"; 

            if (angle >= 270 && angle < 292.5) return "Szeroki Baksztag (część)"; 

            if (angle >= 292.5 && angle < 315) return "Baksztag (część)";

            if (angle >= 315 && angle < 337.5) return "Fordewind (część)"; 

            return "Obliczanie...";
        }






        private string GetWindDirectionName(double angle)
        {
            if (angle < 22.5 || angle >= 337.5) return "Północ";
            if (angle < 67.5) return "Północny Wschód";
            if (angle < 112.5) return "Wschód";
            if (angle < 157.5) return "Południowy Wschód";
            if (angle < 202.5) return "Południe";
            if (angle < 247.5) return "Południowy Zachód";
            if (angle < 292.5) return "Zachód";
            return "Północny Zachód";
        }
        private async void AutomaticMovement()
        {
            while (true)
            {
                MoveSquare(2);
                await Task.Delay(16);
            }
        }

        private void OnRotateLeftClicked(object sender, EventArgs e)
        {
            double relativeWindAngle = (_windAngle - currentRotation + 360) % 360;


            currentRotation -= 15;
            currentRotation = (currentRotation + 360) % 360;
            Square.Rotation = currentRotation;
            //UpdateBoatImage();

            WindName.Text = $"Rodzaj wiatru: {GetWindType(relativeWindAngle)}";
        }

        private void OnRotateRightClicked(object sender, EventArgs e)
        {
            double relativeWindAngle = (_windAngle - currentRotation + 360) % 360;

            currentRotation += 15;
            currentRotation = (currentRotation + 360) % 360;
            Square.Rotation = currentRotation;
            //UpdateBoatImage();

            WindName.Text = $"Rodzaj wiatru: {GetWindType(relativeWindAngle)}";
        }
        /*
        private void UpdateBoatImage()
        {
            double relativeWindAngle = (_windAngle - currentRotation + 360) % 360;

            if (relativeWindAngle >= 0 && relativeWindAngle < 180)
            {
                Square.Source = "statekzagiellewo.png";
            }
            else
            {
                Square.Source = "statekzagielprawo.png";
            }
        }
        */


        private void MoveSquare(double distance)
        {
            double radians = Math.PI * currentRotation / 180;

            double relativeWindAngle = (_windAngle - currentRotation + 360) % 360;
            double targetSpeedFactor = CalculateWindSpeedFactor(relativeWindAngle);

            double deltaX = Math.Cos(radians - Math.PI / 2) * distance * _currentSpeedFactor;
            double deltaY = Math.Sin(radians - Math.PI / 2) * distance * _currentSpeedFactor;

            var animation = new Animation(v =>
            {
                _currentSpeedFactor = v / 100;
                SpeedLabel.Text = $"Prędkość: {v:F0}%";
            }, _currentSpeedFactor * 100, targetSpeedFactor * 100);

            animation.Commit(this, "SpeedAnimation", 16, 1200);

            double newX = positionX + deltaX;
            double newY = positionY + deltaY;

            double squareWidth = Square.WidthRequest;
            double squareHeight = Square.HeightRequest;


            if (newX - 10 < 0 || newX + squareWidth + 10 > BoundaryFrame.Width)
                deltaX = 0;
            if (newY - 10 < 0 || newY + squareHeight + 10 > BoundaryFrame.Height)
                deltaY = 0;

            positionX += deltaX;
            positionY += deltaY;

            Square.TranslationX = positionX;
            Square.TranslationY = positionY;

        }


        private double CalculateWindSpeedFactor(double angleDifference)
        {
            double windFactor = Math.Cos(angleDifference * Math.PI / 180);
            windFactor = (1 - windFactor) / 2;

            return Math.Clamp(windFactor, 0, 1);
        }
    }
}
