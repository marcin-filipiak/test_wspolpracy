﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Sailor
{
    class Boat
    {
        private int rotation = 0;

        public int Rotation { 
            get => rotation; 
            set {
                if (value > 180)
                    value -= 360;
                if (value < -180)
                    value += 360;

                rotation = value;
            }
        }


        public Vector2D Position { get; set; } = new Vector2D(250, 250);
        public float MoveSpeed { get; set; } = 1;

        private const float vectorMag = 1.12f;

        public void Speed(int windDir)
        {
            var tempRotation = rotation;
            var tempWindRotation = windDir;

            var commonRotation = Math.Abs(tempWindRotation - tempRotation);

            commonRotation = Math.Min(commonRotation, 360 - commonRotation);

            switch (commonRotation)
            {
                case 0:
                case 30:
                    MoveSpeed = 2;
                    break;
                case 60:
                case 90:
                    MoveSpeed = 1;
                    break;
                case 120:
                case 150:
                    MoveSpeed = .5f;
                    break;
                case 180:
                    MoveSpeed = 0;
                    break;
            }

            Debug.WriteLine($"{windDir} : {rotation} : {commonRotation} -:- {MoveSpeed}");
        }

        public void Move()
        {
            switch (rotation)
            {
                case 0:
                    Position += new Vector2D(0, -vectorMag) * MoveSpeed;
                    break;
                case 30:
                    Position += new Vector2D(.5f, -1) * MoveSpeed;
                    break;
                case 60:
                    Position += new Vector2D(1, -.5f) * MoveSpeed;
                    break;
                case 90:
                    Position += new Vector2D(vectorMag, 0) * MoveSpeed;
                    break;
                case 120:
                    Position += new Vector2D(1, .5f) * MoveSpeed;
                    break;
                case 150:
                    Position += new Vector2D(.5f, 1) * MoveSpeed;
                    break;
                case 180:
                case -180:
                    Position += new Vector2D(0, vectorMag) * MoveSpeed;
                    break;
                case -150:
                    Position += new Vector2D(-.5f, 1) * MoveSpeed;
                    break;
                case -120:
                    Position += new Vector2D(-1, .5f) * MoveSpeed;
                    break;
                case -90:
                    Position += new Vector2D(-vectorMag, 0) * MoveSpeed;
                    break;
                case -60:
                    Position += new Vector2D(-1, -.5f) * MoveSpeed;
                    break;
                case -30:
                    Position += new Vector2D(-.5f, -1) * MoveSpeed;
                    break;
            }

            if(Position.X < 0)
                Position.X = 0;
            
            if(Position.X > 500)
                Position.X = 500;

            if(Position.Y < 0)
                Position.Y = 0;

            if(Position.Y > 500)
                Position.Y = 500;
        }

    }
}
