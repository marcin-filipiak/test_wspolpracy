﻿using System.Diagnostics;
using System.Numerics;

namespace Sailor
{
    public partial class MainPage : ContentPage
    {

        Boat boat = new Boat();
        int windDirection = 0;

        public MainPage()
        {
            InitializeComponent();
            Prepare();
            compass.Rotation = windDirection;
            Tick();
        }

        private async void Tick()
        {
            var rand = new Random();
            while (true)
            {
                await Task.Delay(40);
                boat.Speed(windDirection);
                UpdateBoat();
            }
        }

        private void UpdateBoat()
        {
            boat.Move();
            Lake.SetLayoutBounds(boatObject, new Rect(boat.Position.X, boat.Position.Y, 64, 64));
        }

        private void Prepare()
        {
            var rand = new Random();
            windDirection = rand.Next(13) * 30;
            windDirection -= 180;
        }

        private void LeftButtonClick(object sender, EventArgs e)
        {
            boat.Rotation += 30;

            boatObject.Rotation = boat.Rotation;
        }
        
        private void RightButtonClick(object sender, EventArgs e)
        {
            boat.Rotation -= 30;

            boatObject.Rotation = boat.Rotation;
        }
    }

}
