﻿namespace MobileAppRejestracja
{
    public partial class MainPage : ContentPage
    {
        public MainPage()
        {
            InitializeComponent();
        }

        private void Button_Clicked(object sender, EventArgs e)
        {
            if(!(Email.Text ?? "").Contains('@'))
            {
                Output.Text = "Nieprawidłowy adres e-mail";
                return;
            }

            if((Password.Text ?? "") != (RepeatPassword.Text ?? ""))
            {
                Output.Text = "Hasła się różnią";
                return;
            }

            string message = "Witaj <e-mail>";

            message = message.Replace("<e-mail>", Email.Text);

            Output.Text = message;

        }
    }

}
