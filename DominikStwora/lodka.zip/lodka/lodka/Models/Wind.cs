﻿namespace lodka.Models;
public class Wind
{
    private Random _random = new Random();
    public double Direction { get; private set; }
    public double Strength { get; private set; } = 5;

    public Wind()
    {
        Direction = _random.Next(0, 72) * 5;
    }

    public void UpdateWindInfo(Label windLabel, Image compassImage)
    {
        windLabel.Text = $"Kierunek wiatru: {Direction}°";
        compassImage.Rotation = Direction;
    }
}

