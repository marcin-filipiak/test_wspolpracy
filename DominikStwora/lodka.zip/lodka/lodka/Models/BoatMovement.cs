﻿namespace lodka.Models;
public class BoatMovement
{
    private Boat _boat;
    private Wind _wind;
    private Image _boatImage;
    private Label _boatLabel;
    private Label _courseLabel;
    private Label _windLabel;
    private Image _compassImage;
    private Label _boatSpeedLabel;
    private Label _windSpeedLabel;

    public BoatMovement(Boat boat, Wind wind, Image boatImage, Label boatLabel, Label courseLabel, Label windLabel, Image compassImage, Label boatSpeedLabel, Label windSpeedLabel)
    {
        _boat = boat;
        _wind = wind;
        _boatImage = boatImage;
        _boatLabel = boatLabel;
        _courseLabel = courseLabel;
        _windLabel = windLabel;
        _compassImage = compassImage;
        _boatSpeedLabel = boatSpeedLabel;
        _windSpeedLabel = windSpeedLabel;
    }

    public void StartBoatMovement()
    {
        Device.StartTimer(TimeSpan.FromMilliseconds(200), () =>
        {
            _boat.UpdateSpeed(_wind.Direction);
            _boat.UpdateSailingCourse(_wind.Direction, _boatImage);

            double boatX = _boatImage.TranslationX;
            double boatY = _boatImage.TranslationY;
            double boatWidth = _boatImage.WidthRequest;
            double boatHeight = _boatImage.HeightRequest;
            double oceanWidth = 750;
            double oceanHeight = 600;

            _boat.UpdatePosition(ref boatX, ref boatY, _boat.Speed, boatWidth, boatHeight, oceanWidth, oceanHeight);

            _boatImage.TranslationX = boatX;
            _boatImage.TranslationY = boatY;

            _boatSpeedLabel.Text = $"Prędkość łódki: {Math.Round(_boat.SpeedInKnots, 2)} węzłów";
            _windSpeedLabel.Text = $"Prędkość wiatru: {Math.Round(_wind.Strength * 0.53996, 2)} węzłów";

            _boat.UpdateCourse(_wind.Direction, _boatLabel, _courseLabel);
            _wind.UpdateWindInfo(_windLabel, _compassImage);

            return true;
        });
    }
}

