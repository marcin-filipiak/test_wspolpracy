﻿namespace lodka.Models;
public class Boat
{
    private const double deadAngle = 10;
    private double _rotation = 0;
    private double _speed = 0;
    private double _windStrength = 5;

    private string? _currentSailImage;

    public double Rotation => _rotation;
    public double Speed => _speed;
    public double SpeedInKnots => _speed * 0.53996;
    public void UpdateSpeed(double windDirection)
    {
        double angleDifference = Math.Abs(_rotation - windDirection) % 360;
        if (angleDifference > 180) angleDifference = 360 - angleDifference;
        _speed = _windStrength * (1 - Math.Cos(angleDifference * Math.PI / 180));
    }

    public void UpdatePosition(ref double boatX, ref double boatY, double boatSpeed, double boatWidth, double boatHeight, double oceanWidth, double oceanHeight)
    {
        double boatRadians = _rotation * Math.PI / 180;
        boatX += Math.Cos(boatRadians) * boatSpeed * 0.5;
        boatY += Math.Sin(boatRadians) * boatSpeed * 0.5;

        boatX = Math.Max(-oceanWidth / 2 + boatWidth / 2, Math.Min(boatX, oceanWidth / 2 - boatWidth / 2));
        boatY = Math.Max(-oceanHeight / 2 + boatHeight / 2, Math.Min(boatY, oceanHeight / 2 - boatHeight / 2));
    }

    public void UpdateCourse(double windDirection, Label boatLabel, Label courseLabel)
    {
        double relativeAngle = Math.Abs((_rotation - windDirection + 360) % 360);
        double adjustedAngle = relativeAngle > 180 ? 360 - relativeAngle : relativeAngle;
        string courseName;

        if (adjustedAngle <= deadAngle)
            courseName = "Kąt martwy";
        else if (adjustedAngle > deadAngle && adjustedAngle <= 45)
            courseName = "Bajdewind";
        else if (adjustedAngle > 45 && adjustedAngle <= 90)
            courseName = "Półwiatr";
        else if (adjustedAngle > 90 && adjustedAngle <= 135)
            courseName = "Baksztag";
        else
            courseName = "Fordewind";

        boatLabel.Text = $"Kierunek łódki: {_rotation}°";
        courseLabel.Text = $"Kurs żeglarski: {courseName} ({relativeAngle}°)";
    }

    public void UpdateSailingCourse(double windDirection, Image boatImage)
    {
        double relativeAngle = Math.Abs((_rotation - windDirection + 360) % 360);
        double adjustedRelativeAngle = relativeAngle >= 180 ? Math.Abs(relativeAngle - 360) : relativeAngle;

        string newImageSource;
        string direction = (relativeAngle >= 0 && relativeAngle < 180) ? "R" : "L";

        if (adjustedRelativeAngle <= deadAngle)
            newImageSource = "dead_sail.png";
        else if (adjustedRelativeAngle > deadAngle && adjustedRelativeAngle <= 135)
            newImageSource = direction == "R" ? "right_sail.png" : "left_sail.png";
        else
            newImageSource = "fordewind_sail.png";

        if (_currentSailImage != newImageSource)
        {
            _currentSailImage = newImageSource;
            boatImage.Source = newImageSource;
        }
    }

    public void ChangeDirection(double angle)
    {
        _rotation = (_rotation + angle) % 360;
        if (_rotation < 0) _rotation += 360;
    }
}
