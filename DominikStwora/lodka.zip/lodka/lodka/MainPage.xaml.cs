﻿using lodka.Models;

namespace lodka;

public partial class MainPage : ContentPage
{
    private Boat _boat;
    private Wind _wind;
    private BoatMovement _boatMovement;

    public MainPage()
    {
        InitializeComponent();
        _boat = new Boat();
        _wind = new Wind();
        _boatMovement = new BoatMovement(_boat, _wind, BoatImage, BoatLabel, CourseLabel, WindLabel, CompassImage, BoatSpeedLabel, WindSpeedLabel);
        _boatMovement.StartBoatMovement();
    }

    private void OnLeftButtonClicked(object sender, EventArgs e)
    {
        _boat.ChangeDirection(-10);
        BoatImage.Rotation = _boat.Rotation;
        BoatLabel.Text = $"Kierunek łódki: {_boat.Rotation}°";
    }

    private void OnRightButtonClicked(object sender, EventArgs e)
    {
        _boat.ChangeDirection(10);
        BoatImage.Rotation = _boat.Rotation;
        BoatLabel.Text = $"Kierunek łódki: {_boat.Rotation}°";
    }
}
