﻿namespace Rejestracja;

public partial class MainPage : ContentPage
{
    public MainPage()
    {
        InitializeComponent();
    }

    private void OnButtonClicked(object sender, EventArgs e)
    {
        string _email = email.Text;
        string _password = password.Text;
        string _repeatPassword = repeat_password.Text;

        if (!_email.Contains("@"))
        {
            result.Text = "Nieprawidłowy adres e-mail";
            return;
        }

        if (_password != _repeatPassword)
        {
            result.Text = "Hasła się różnią";
            return;
        }

        result.Text = $"Witaj {_email}";
    }
}
