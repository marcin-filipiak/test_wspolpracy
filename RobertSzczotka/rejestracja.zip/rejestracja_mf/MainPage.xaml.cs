﻿namespace rejestracja_mf
{
    public partial class MainPage : ContentPage
    {
        public MainPage()
        {
            InitializeComponent();
        }

        private void OnSubmitClicked(object sender, EventArgs e)
        {
            string email = EmailEntry.Text?.Trim() ?? string.Empty;
            string password = PasswordEntry.Text ?? string.Empty;
            string confirmPassword = ConfirmPasswordEntry.Text ?? string.Empty;

            if (!email.Contains("@"))
            {
                MessageLabel.Text = "Nieprawidłowy adres e-mail";
                return;
            }

            if (password != confirmPassword)
            {
                MessageLabel.Text = "Hasła się różnią";
                return;
            }

            MessageLabel.Text = $"Witaj {email}";
        }
    }
}
