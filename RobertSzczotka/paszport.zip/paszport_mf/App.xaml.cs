﻿using System.Configuration;
using System.Data;
using System.Windows;

namespace paszport_mf;

/// <summary>
/// Interaction logic for App.xaml
/// </summary>
public partial class App : Application
{
}

