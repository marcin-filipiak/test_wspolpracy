﻿using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace paszport_mf;

public partial class MainWindow : Window
{
    public MainWindow()
    {
        InitializeComponent();

    }

    private void Button_Click(object sender, RoutedEventArgs e)
    {
        if (NameInput.Text != "" && SurnameInput.Text != "")
        {
            string selectedEyeColor = "niebieskie";

            foreach (RadioButton rb in EyeColorPanel.Children.OfType<RadioButton>())
            {
                if (rb.IsChecked == true)
                {
                    selectedEyeColor = rb.Content.ToString();
                    break;
                }
            }

            MessageBox.Show($"{NameInput.Text} {SurnameInput.Text} kolor oczu {selectedEyeColor}");
        }
        else
        {
            MessageBox.Show("Wprowadź dane");
        }
    }

    private void NumberInput_LostKeyboardFocus(object sender, KeyboardFocusChangedEventArgs e)
    {
        if (!string.IsNullOrEmpty(NumberInput.Text))
        {
            try
            {
                string imagePath = $"/Resources/{NumberInput.Text}-zdjecie.jpg";
                string fingerprintPath = $"/Resources/{NumberInput.Text}-odcisk.jpg";

                zdjecieImage.Source = new BitmapImage(new Uri(imagePath, UriKind.Relative));
                odciskImage.Source = new BitmapImage(new Uri(fingerprintPath, UriKind.Relative));
            }
            catch
            {

            }
        }
    }
}