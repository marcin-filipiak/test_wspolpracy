﻿using Microsoft.Maui.Controls;
using Microsoft.Maui.Graphics;
using System.ComponentModel;

namespace sailing;

public partial class MainPage : ContentPage, INotifyPropertyChanged
{
    private double _boatAngle;
    public double BoatAngle
    {
        get => _boatAngle;
        set
        {
            _boatAngle = (value % 360 + 360) % 360;
            OnPropertyChanged(nameof(BoatAngle));
            UpdateSailState();
        }
    }

    private double _windAngle;
    private bool _isMoving;
    private Point _position;
    private readonly IDispatcherTimer _timer;
    private double _screenWidth;
    private double _screenHeight;
    private bool _userPaused = false;


    public MainPage()
    {
        InitializeComponent();
        BindingContext = this;

        var random = new Random();
        _windAngle = random.Next(0, 360);
        StatusLabel.Text = $"Wiatr startowy: {_windAngle:0}°";

        BoatContainer.SizeChanged += OnBoatContainerSizeChanged;

        var displayInfo = DeviceDisplay.Current.MainDisplayInfo;
        _screenWidth = displayInfo.Width / displayInfo.Density;
        _screenHeight = displayInfo.Height / displayInfo.Density;

        _position = new Point(_screenWidth / 2, _screenHeight / 2);

        _timer = Dispatcher.CreateTimer();
        _timer.Interval = TimeSpan.FromMilliseconds(16);
        _timer.Tick += (s, e) => UpdatePosition();

        Resources.Add("WindDrawable", new WindDrawable(this));
        WindIndicator.Drawable = new WindDrawable(this);

        _isMoving = true;
        _timer.Start();
        UpdateTimer();
    }

    private void OnBoatContainerSizeChanged(object sender, EventArgs e)
    {
        _screenWidth = BoatContainer.Width;
        _screenHeight = BoatContainer.Height;
        _position = new Point(_screenWidth / 2, _screenHeight / 2);

    }

    private void UpdatePosition()
    {
        if (!_isMoving || _userPaused) return;

        double deltaX = Math.Sin(BoatAngle * Math.PI / 180);
        double deltaY = -Math.Cos(BoatAngle * Math.PI / 180);

        double newX = _position.X + deltaX;
        double newY = _position.Y + deltaY;

        double minX = 0;
        double maxX = _screenWidth - BoatImage.WidthRequest;
        newX = Math.Clamp(newX, minX, maxX);

        double minY = 0;
        double maxY = _screenHeight - BoatImage.HeightRequest;
        newY = Math.Clamp(newY, minY, maxY);

        _position = new Point(newX, newY);

        BoatImage.TranslationX = _position.X - (BoatImage.WidthRequest * BoatImage.AnchorX);
        BoatImage.TranslationY = _position.Y - (BoatImage.HeightRequest * BoatImage.AnchorY);


        UpdateStatus();
    }

    private void UpdateStatus()
    {
        string movingStatus = (_isMoving && !_userPaused) ? "Ruch: Tak" : "Ruch: Nie";
        StatusLabel.Text = $"Łódka: {BoatAngle:0}°\nWiatr: {_windAngle:0}°\n{movingStatus}";
    }


    private void OnTurnLeft(object sender, EventArgs e) => BoatAngle -= 30;
    private void OnTurnRight(object sender, EventArgs e) => BoatAngle += 30;

    private void OnSetWind(object sender, EventArgs e)
    {
        if (double.TryParse(WindInput.Text, out var angle))
        {
            _windAngle = (angle % 360 + 360) % 360;
            UpdateStatus();
            UpdateSailState();
        }
    }

    private void OnSetRandomWind(object sender, EventArgs e)
    {
        var random = new Random();
        _windAngle = random.Next(0, 360);
        UpdateStatus();
        WindIndicator.Invalidate();
    }
    private void UpdateTimer()
    {
        if (_isMoving && !_userPaused)
        {
            if (!_timer.IsRunning) _timer.Start();
        }
        else
        {
            if (_timer.IsRunning) _timer.Stop();
        }
    }
    private void OnStartStopClicked(object sender, EventArgs e)
    {
        _userPaused = !_userPaused;
        UpdateTimer();
        UpdateStatus();
        UpdateSailState();
    }

    private void UpdateSailState()
    {
        double angleDifference = (BoatAngle - _windAngle + 360) % 360;
        angleDifference = angleDifference > 180 ? angleDifference - 360 : angleDifference;

        if (Math.Abs(angleDifference) < 45)
        {
            BoatImage.Source = "no_sail.png";
            _isMoving = false;
        }
        else
        {
            _isMoving = true;

            if (Math.Abs(angleDifference) < 90)
            {
                BoatImage.Source = "sail_middle.png";
            }
            else
            {
                BoatImage.Source = angleDifference > 0 ? "sail_right.png" : "sail_left.png";
            }
        }

        WindIndicator.Invalidate();
        UpdateTimer();
    }



    public class WindDrawable : IDrawable
    {
        private MainPage _page;

        public WindDrawable(MainPage page)
        {
            _page = page;
        }

        public void Draw(ICanvas canvas, RectF dirtyRect)
        {
            canvas.StrokeColor = Colors.White;
            canvas.StrokeSize = 3;

            Point center = new Point(dirtyRect.Width / 2, 80);

            // Adjust the wind angle by 180 degrees to reverse the arrow
            double adjustedAngle = (_page._windAngle + 180) % 360;
            double angleInRadians = adjustedAngle * Math.PI / 180;

            Point end = new Point(
                center.X + Math.Sin(angleInRadians) * 50,
                center.Y - Math.Cos(angleInRadians) * 50
            );

            // Draw the main line of the arrow
            canvas.DrawLine(center, end);

            // Calculate points for the arrowhead
            double arrowAngle = 30; // Angle between arrowhead lines and the main line
            double arrowLength = 15; // Length of the arrowhead lines

            Point arrowLeft = new Point(
                end.X - arrowLength * Math.Sin((adjustedAngle - arrowAngle) * Math.PI / 180),
                end.Y + arrowLength * Math.Cos((adjustedAngle - arrowAngle) * Math.PI / 180)
            );

            Point arrowRight = new Point(
                end.X - arrowLength * Math.Sin((adjustedAngle + arrowAngle) * Math.PI / 180),
                end.Y + arrowLength * Math.Cos((adjustedAngle + arrowAngle) * Math.PI / 180)
            );

            // Draw the arrowhead
            canvas.DrawLine(end, arrowLeft);
            canvas.DrawLine(end, arrowRight);
        }


    }
}
