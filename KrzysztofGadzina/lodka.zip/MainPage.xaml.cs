﻿namespace boatka
{
    public partial class MainPage : ContentPage
    {
        private Boat boat;
        private double boatX = 250, boatY = 250;
        private const int MoveInterval = 50;
        private double windAngle = 0;
        Random rng = new ();


        public MainPage()
        {
            InitializeComponent();
            boat = new Boat();
            windAngle = rng.Next(-180, 181);
            ConstantMovement();
            UpdateUI();
        }


        private async Task ConstantMovement()
        {
            while (true)
            {
                MoveBoat();
                await Task.Delay(MoveInterval);
            }
        }

        private bool MoveBoat()
        {
            double prevX = boatX;
            double prevY = boatY;

            boat.MoveForward(ref boatX, ref boatY);

            if (prevX != boatX || prevY != boatY)
            {
                UpdateUI();
            }

            return true;
        }

        private void OnRotateLeft(object sender, EventArgs e)
        {
            boat.RotateLeft();
            if (boat.RotationAngle < -180)
            {
                boat.RotationAngle += 360;
            }
            UpdateUI();
        }

        private void OnRotateRight(object sender, EventArgs e)
        {
            boat.RotateRight();
            if (boat.RotationAngle > 180)
            {
                boat.RotationAngle -= 360;
            }
            UpdateUI();
        }

        private void GenerateWind(object sender, EventArgs e)
        {
            windAngle = rng.Next(-180, 181);
        }


   

        private void UpdateUI()
        {
            BoatDirectionLabel.Text = $"Kierunek łódki: {boat.RotationAngle}°";
            WindDirectionLabel.Text = $"Kierunek wiatru: {windAngle}°";
            SailingCourseLabel.Text = $"Kurs żeglarski: {boat.SailingCourse}";

            BoatView.TranslationX = boatX;
            BoatView.TranslationY = boatY;
            BoatView.Rotation = boat.RotationAngle + 90;
        }
    }
}
