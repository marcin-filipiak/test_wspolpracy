﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace boatka
{
    public class Boat
    {
        public double RotationAngle { get;  set; } = 0;
        public string SailingCourse { get; set; } = "Podstawowy kurs";
        public int Speed { get; set; } = 50;

        public void RotateLeft()
        {
            RotationAngle = (RotationAngle - 15) % 360;
        }

        public void RotateRight()
        {
            RotationAngle = (RotationAngle + 15) % 360;
        }

        public void MoveForward(ref double x, ref double y)
        {
            double radians = RotationAngle * Math.PI / 180;
            double step = 2;
            x += Math.Cos(radians) * step;
            y += Math.Sin(radians) * step;
        }
    }

}
