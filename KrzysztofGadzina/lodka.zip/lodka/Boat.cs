﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace boatka
{
    public class Boat
    {
        public double RotationAngle { get;  set; } = 0;
        public string SailingCourse { get; set; } = "Podstawowy kurs";
        public double Speed { get; set; } = 1;

        public void RotateLeft()
        {
            RotationAngle = (RotationAngle - 15) % 360;
        }

        public void RotateRight()
        {
            RotationAngle = (RotationAngle + 15) % 360;
        }

        public void MoveForward(ref double x, ref double y)
        {
            double radians = RotationAngle * Math.PI / 180;
            double step = 2;
            x += Math.Cos(radians) * Speed * step;
            y += Math.Sin(radians) * Speed * step;
        }
    }

}
