﻿using System.Diagnostics;

namespace boatka
{
    public partial class MainPage : ContentPage
    {
        private Boat boat;
        private double boatX = 250, boatY = 250;
        private const int MoveInterval = 30;
        private double windAngle = 0;
        Random rng = new ();


        public MainPage()
        {
            InitializeComponent();
            boat = new Boat();
            windAngle = rng.Next(0, 361);
            ConstantMovement();
            UpdateUI();
        }


        private async Task ConstantMovement()
        {
            while (true)
            {
                MoveBoat();
                await Task.Delay(MoveInterval);
            }
        }

        private bool MoveBoat()
        {
            double prevX = boatX;
            double prevY = boatY;

            boat.MoveForward(ref boatX, ref boatY);

            if(boatX < -75)
            {
                boatX = -75;
            }
            else if (boatX > 675)
            {
                boatX = 675;
            }

            if (boatY < -50)
            {
                boatY = -50;
            }
            else if (boatY > 500)
            {
                boatY = 500;
            }

            if (prevX != boatX || prevY != boatY)
            {
                UpdateUI();
            }

            ChangeSpeed();

            return true;
        }

        private void OnRotateLeft(object sender, EventArgs e)
        {
            boat.RotateLeft();
            if (boat.RotationAngle < 0)
            {
                boat.RotationAngle = 345;
            }

            UpdateUI();
        }

        private void OnRotateRight(object sender, EventArgs e)
        {
            boat.RotateRight();
            if (boat.RotationAngle > 360)
            {
                boat.RotationAngle = 15;
            }
            UpdateUI();
        }

        private void GenerateWind(object sender, EventArgs e)
        {
            windAngle = rng.Next(0, 361);
        }

        private void ChangeSpeed()
        {
            double targetSpeed;

            if (boat.SailingCourse == "Kąt martwy (pole martwe)")
            {
                targetSpeed = 0;
            }
            else if (boat.SailingCourse.Contains("Wiatr ostry"))
            {
                targetSpeed = 0.25;
            }
            else if (boat.SailingCourse.Contains("Wiatr półwiatr"))
            {
                targetSpeed = 0.50;
            }
            else if (boat.SailingCourse.Contains("Wiatr pełny"))
            {
                targetSpeed = 0.65;
            }
            else if (boat.SailingCourse.Contains("Wiatr baksztag"))
            {
                targetSpeed = 0.85;
            }
            else
            {
                targetSpeed = 1;
            }

            this.Animate("SpeedChange", (val) => boat.Speed = val, boat.Speed, targetSpeed, 16, 500, Easing.Linear);

        }


        private void DetermineWindType()
        {

            var angle = (windAngle - boat.RotationAngle + 360) % 360;

            switch (angle)
            {
                case >= 330:
                case <= 30:
                    boat.SailingCourse = "Fordewind";
                    break;
                case > 30 and <= 60:
                    boat.SailingCourse = "Wiatr baksztag lewy";
                    break;
                case > 60 and <= 90:
                    boat.SailingCourse = "Wiatr półwiatr lewy";
                    break;
                case > 90 and <= 120:
                    boat.SailingCourse = "Wiatr pełny lewy";
                    break;
                case > 120 and < 150:
                    boat.SailingCourse = "Wiatr ostry lewy";
                    break;
                case < 330 and >= 300:
                    boat.SailingCourse = "Wiatr baksztag prawy";
                    break;
                case < 300 and >= 270:
                    boat.SailingCourse = "Wiatr półwiatr prawy";
                    break;
                case < 270 and >= 240:
                    boat.SailingCourse = "Wiatr pełny prawy";
                    break;
                case < 250 and >= 210:
                    boat.SailingCourse = "Wiatr ostry prawy";
                    break;
                default:
                    boat.SailingCourse = "Kąt martwy (pole martwe)";
                    break;
            }
        }

        private void ChangeImage()
        {
            var newSource = new FileImageSource();

            switch (boat.SailingCourse)
            {
                case "Fordewind":
                    newSource.File = "lodka_prosto.png";
                    break;
                case "Wiatr baksztag lewy":
                    newSource.File = "lodka_pol_prawo.png";
                    break;
                case "Wiatr półwiatr lewy":
                case "Wiatr pełny lewy":
                case "Wiatr ostry lewy":
                    newSource.File = "lodka_prawo.png";
                    break;
                case "Wiatr baksztag prawy":
                    newSource.File = "lodka_pol_lewo.png";
                    break;
                case "Wiatr pełny prawy":
                case "Wiatr półwiatr prawy":
                case "Wiatr ostry prawy":
                    newSource.File = "lodka_lewo.png";
                    break;
                case "Kąt martwy (pole martwe)":
                    newSource.File = "lodka_prosto.png";
                    break;
            }

            if (BoatView.Source is FileImageSource currentSource && currentSource.File == newSource.File)
                return;

            BoatView.Source = newSource;

        }


        private void UpdateUI()
        {
            BoatDirectionLabel.Text = $"Kierunek łódki: {boat.RotationAngle}°";
            WindDirectionLabel.Text = $"Kierunek wiatru: {windAngle}°";
            DetermineWindType();
            SailingCourseLabel.Text = $"Kurs żeglarski: {boat.SailingCourse}";

            ChangeImage();

            BoatView.TranslationX = boatX;
            BoatView.TranslationY = boatY;
            BoatView.Rotation = boat.RotationAngle + 90;
        }
    }
}
