﻿namespace Rejestracja
{
    public partial class MainPage : ContentPage
    {
        int count = 0;

        public MainPage()
        {
            InitializeComponent();
            KomunikatBox.Text = "Autor: Krzysztof Gadzina";
        }


        private void SubmitBtn_Clicked(object sender, EventArgs e)
        {
            string email = Email.Text;
            string password = Password.Text;
            string passwordRepeat = RepeatPassword.Text;
            if (!(email.Contains("@")))
            {
                KomunikatBox.Text = "Nieprawidłowy adres e-mail";
                return;
            }
            if (password != passwordRepeat)
            {
                KomunikatBox.Text = "Hasła się różnią";
                return;
            }
            if ((email.Contains("@")) && (password == passwordRepeat))
            {
                KomunikatBox.Text = $"Witaj {email}";
                return;
            }
        }
    }

}
