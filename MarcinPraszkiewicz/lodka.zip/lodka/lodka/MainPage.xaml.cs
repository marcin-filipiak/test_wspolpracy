﻿

using Microsoft.Maui.Controls;
using Microsoft.Maui.Graphics;
using System;
using System.Timers;

namespace lodka
{
    public partial class MainPage : ContentPage
    {
        private double boatPositionX = 0;
        private double boatPositionY = 0;
        private double lastboatPositionX = 0;
        private double lastBoatPositionY = 0;
        private int directionAngle = 0; // kąt obrotu łódki w stopniach
        private int WindDirection = 0;
        private const double speed = 5; // pikseli na sekundę
        private const double windSpeed = 5; // pikseli na sekundę
        private int imgReloadInterval = 0;

        private System.Timers.Timer timer;
        private GraphicsView canvas;
        private Image boat;
        private Image windImg;

        public MainPage()
        {
            InitializeComponent();
            CreateUI();
            StartBoatMovement();
        }

        private void CreateUI()
        {
            var r = new Random();
            WindDirection = r.Next(360);
            boat = new Image
            {
                Source = "boat.jpg", 
                WidthRequest = 50,
                HeightRequest = 100,

            };
            windImg = new Image
            {
                Source = "dir.png",
                WidthRequest = 50,
                HeightRequest = 50,
            };


            //AbsoluteLayout layout = new AbsoluteLayout();
            //AbsoluteLayout.SetLayoutBounds(boat, new Rect(boatPositionX, boatPositionY, 100, 50));
            //AbsoluteLayout.SetLayoutBounds(boat, new Rect(0, 0, 200, 300));
            layout.HeightRequest = 200;
            layout.WidthRequest = 9000;

            //layout.BackgroundColor = Color.FromRgb(0, 0, 255);

            layout.Children.Add(windImg);
            layout.Children.Add(boat);
            ///Content = layout;
        }

        private void StartBoatMovement()
        {
            timer = new System.Timers.Timer(100);
            timer.Elapsed += (sender, e) => MoveBoat();
            timer.Start();
        }
        private void Wind()
        {
            double radians = Math.PI * WindDirection / 180.0;
            lastboatPositionX = boatPositionX;
            boatPositionX += windSpeed * Math.Cos(radians);
            //if (boatPositionX < Window.Width / 2 && lastboatPositionX > boatPositionX)
            //{
            //    boatPositionX -= windSpeed * Math.Cos(radians);
            //}
            boatPositionY += windSpeed * Math.Sin(radians);
            //if (boatPositionX < Window.Height/2 && lastBoatPositionY > boatPositionY)
            //{
                boatPositionY -= windSpeed * Math.Sin(radians);
            //}
            imgReloadInterval++;
            if (imgReloadInterval >= 20)
            {
                imgReloadInterval = 0;
                var diff = Math.Abs(directionAngle - WindDirection);
                if ( diff < 15 && diff > -15)
                {
                    windImg.Rotation = WindDirection+90;
                    boat.Source = "boat.jpg";
                }
                else if (diff > 15)
                {
                    windImg.Rotation = WindDirection+90;
                    boat.Source = "boat_left.jpg";
                }
                else
                {
                    windImg.Rotation = WindDirection + 90;
                    boat.Source = "boat_right.jpg";
                }
            }
        }
        private void MoveBoat()
        {
            MainThread.BeginInvokeOnMainThread(() =>
            {
                double radians = Math.PI * directionAngle / 180.0;
                Wind();
                //if (boatPositionX < Window.Width/2)
                boatPositionX += speed * Math.Cos(radians);
                //if (boatPositionX < Window.Height/2)
                    boatPositionY += speed * Math.Sin(radians);
                if (boatPositionX < Window.Height / 2)
                    boat.TranslationX = boatPositionX;
                if (boatPositionX < Window.Height / 2)
                    boat.TranslationY = boatPositionY;
                boat.Rotation = directionAngle;
                //value.Text=directionAngle.ToString()+WindDirection.ToString();
                var w = Window.Width;//Microsoft.Maui.Devices.DeviceDisplay.MainDisplayInfo.Width;
                value.Text = ((WindDirection+90)%360).ToString() + "° - kierunek wiatru ";
            });
        }

        private void Button_Clicked(object sender, EventArgs e)
        {
            boat.Rotation -= 10;
            directionAngle -= 10;
            
        }

        private void Button_Clicked_1(object sender, EventArgs e)
        {
            boat.Rotation += 10;
            directionAngle += 10;
        }
    }
}

